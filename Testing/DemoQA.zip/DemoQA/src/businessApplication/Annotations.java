package businessApplication;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;


/**
 * This class tests the application functionality on a Browser
 * @author vijayj
 *
 */
public class Annotations 
{
	public String baseUrl = "http://demo.guru99.com/test/newtours/";
	String driverPath = "C:\\chromedriver.exe";
	WebDriver driver = null;

	/**
	 * This method invokes the browser and load the application
	 */
	public void launchBrowser() 
	{
		System.out.println("launching browser"); 
		System.setProperty("webdriver.chrome.driver", driverPath);
		driver = new ChromeDriver();
		driver.get(baseUrl);
	}
	/**
	 * This method returns the title of the home page of the application 
	 * @return
	 */
	public String verifyHomepageTitle() 
	{
		
		String actualTitle = driver.getTitle();
		return actualTitle;
		
	}

	/**
	 * This method closes the already opened browser
	 */
	public void terminateBrowser()
	{
		driver.close();
	}
}
