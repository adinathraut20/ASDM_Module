package businessApplication;

/**
 * 
 * @author vijayj
 *
 */
public class MessageUtil 
{
	   private String message;
	   /**
	    * 
	    * @param message
	    */
	   public MessageUtil(String message) 
	   {
	      this.message = message;
	   }

	  /**
	   * 
	   * @return
	   */
	   public String printMessage() 
	   {
	      System.out.println(message);
	      return message;
	   }   
	} 