package testNg;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import businessApplication.EmpBusinessLogic;
import businessApplication.EmployeeDetails;

/**
 * 
 * @author vijayj
 *
 */
public class TestEmployeeDetails 
{
   EmpBusinessLogic empBusinessLogic = new EmpBusinessLogic();
   EmployeeDetails employee = new EmployeeDetails();
   double salary = 0.0;
   /**
    * Test to check appraisal amount
    * @param name
    * @param age
    * @param sal
    * @param appr
    */
   @Test
   @Parameters({"name", "age", "appr"})
   public void testCalculateAppriasal(String name, int age, double appr) 
   {
      employee.setName(name);
      employee.setAge(age);
      employee.setMonthlySalary(salary);
      double appraisal = empBusinessLogic.calculateAppraisal(employee);
      System.out.println("Appraisal Amount:"+appraisal);
      Assert.assertEquals(appr, appraisal, 0.0, "Appraisal Amount:"+appraisal);
   }

   /**
    * Test to check yearly salary
    * @param name
    * @param age
    * @param sal
    * @param expected
    */
   @Test
   @Parameters({"name", "age", "sal","expected"})
   public double testCalculateYearlySalary(String name, int age, double sal, double expected) 
   {
      employee.setName(name);
      employee.setAge(age);
      employee.setMonthlySalary(sal);
      salary = empBusinessLogic.calculateYearlySalary(employee);
      System.out.println("Salary Amount:"+salary);
      Assert.assertEquals(expected, salary, 0.0, "Monthly Salary:"+sal);
      return salary;
   }
   
   /**
    * 
    */
   @BeforeSuite
   public void beforeSuite() 
   {
      System.out.println("Test Suite is Ready to Run");
   }

   @AfterSuite
   public void afterSuite() 
   {
      System.out.println("Test Suite is completed");
   }
   
   @BeforeTest
   public void beforeTest() 
   {
      System.out.println("Test Case is Ready to Run");
   }

   @AfterTest
   public void afterTest() 
   {
      System.out.println("Test Case Run Completed");
   }

   @BeforeClass
   public void beforeClass() 
   {
      System.out.println("Methods in class: TestEmployeeDetails are getting tested");
   }

   @AfterClass
   public void afterClass() 
   {
      System.out.println("Methods in class: TestEmployeeDetails completed testing. Verify the results");
   }
   
}