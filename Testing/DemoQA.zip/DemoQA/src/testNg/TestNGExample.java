package testNg;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import businessApplication.MessageUtil;


public class TestNGExample 
{
   String message = "Test NG";	
   MessageUtil messageUtil = new MessageUtil(message);

	
	  @Test
	  
	  @Parameters("testValue") public void testPrintMessage(String testValue) {
	  Assert.assertEquals(testValue,messageUtil.printMessage()); }
	 
   
   @Test
   public void testPrintMessage1() 
   {	  
	   String valueToTest="Test NG";
	   Assert.assertEquals(valueToTest,messageUtil.printMessage());
   }
}