package testNg;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import businessApplication.Annotations;

/**
 * 
 * @author vijayj
 *
 */
public class AnnotationTest 
{
	Annotations ann= new Annotations();
	
	@BeforeTest
	public void testBrowser() 
	{	  
		ann.launchBrowser(); 
	}

	@Test
	@Parameters(value="pageValue")
	public void verifyContent(String pageValue) 
	{	  
		//String expectedTitle = "Welcome: Mercury Tours";
		String expectedTitle = pageValue;
		Assert.assertEquals(expectedTitle,ann.verifyHomepageTitle());
	}
	
	/**
	 * 
	 */
	@AfterTest
	public void terminateBrowser()
	{
		ann.terminateBrowser();
	}
	
}
