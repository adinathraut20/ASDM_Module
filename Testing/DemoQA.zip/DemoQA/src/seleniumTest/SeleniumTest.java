package seleniumTest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class SeleniumTest 
{
    public static void main(String[] args) 
    {
        String driverPath="B:\\Testing\\drivers\\chromedriver.exe";
    	// declaration and instantiation of objects/variables
    	System.setProperty("webdriver.chrome.driver",driverPath);
		WebDriver driver = new ChromeDriver();
		String baseUrl = "http://www.google.com/";
        String expectedTitle = "Google1";
        String actualTitle = "";

        // launch Browser and direct it to the Base URL
        driver.get(baseUrl);

        // get the actual value of the title
        actualTitle = driver.getTitle();
        
        
        /*
         * compare the actual title of the page with the expected one and print
         * the result as "Passed" or "Failed"
         */
        if (actualTitle.contentEquals(expectedTitle))
        {
            System.out.println("Test Passed!");
        } 
        else 
        {
            System.out.println("Test Failed");
        }
        //Close the Browser
        driver.close();
    }
}
